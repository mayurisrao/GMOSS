Filename : GMOSS_40_200_MHz.txt
Author : Mayuri S.Rao
GMOSS sky-model

The data is in HEALPIX Nested Scheme with NSIDE 16 and 5 degrees resolution. The file 'GMOSS_40_200_MHz.txt' contains GMOSS spectra generated at the 3072 pixels. The first row gives the frequency [GHz]. Sky spectra are in Kelvin units.
Frequency range : 40 - 200 MHz
Resolution : 1 MHz
